class Livro{

  int id;
  String nome;
  String tipo;

  Livro({
    this.id,
    this.nome,
    this.tipo
  }
      );

}