abstract class Rotas{

  static const HOME = '/home';
  static const CADASTROLIVROS = '/cadastro_livros';
  static const DADOSLIVROS = '/dados_livros';

}