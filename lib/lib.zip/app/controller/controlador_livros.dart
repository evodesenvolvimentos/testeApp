

import 'package:get/get.dart';
import 'package:getx_envia_retorna/app/data/model/livro.dart';
import 'package:getx_envia_retorna/app/routes/app_rotas.dart';

class LivrosControlador extends GetxController{

  Livro livro = Livro();
  int indexLivroClicado;
  RxBool indice = false.obs;
  Livro livroClicado = null;
  Livro livroTestando = Livro();

  // lista de livros observáveis
  RxList<Livro> listaLivros = <Livro>[].obs;
  RxList<Livro> listaFiltrada = <Livro>[].obs;

  @override
  void onInit() {
    carregaLivros();
    super.onInit();
  }


  void cliqueLivro([Livro livro, int index]) async{
    var retorno = await Get.toNamed(Rotas.DADOSLIVROS,arguments: livro);
    if (retorno != null){
      livroTestando = retorno;
      atualizarListas(retorno,index);
      print('retorno ; ${livroTestando.tipo.toString()}');
      print('index ; ${index}');

    }
  }

  Future<void> atualizarListas(Livro livroAlterado, int index)async{

    // TODO: NÃO ESTÁ ATUALIZANDO EM TELA

    print(listaLivros[index].nome.toString());
    listaLivros[index].nome = livroAlterado.nome;
    listaLivros[index].tipo = livroAlterado.tipo;
    print('aaaa  ${listaLivros[index].nome.toString()}');

    print(listaFiltrada[index].tipo.toString());
    listaFiltrada[index].nome = livroAlterado.nome;
    listaFiltrada[index].tipo = livroAlterado.tipo;
    print('bbbbb  ${listaFiltrada[index].tipo.toString()}');

  }


  void carregaLivros(){
    geraDadosLivro(1, 'João e Maria', 'Literatura');
    geraDadosLivro(2, 'Geografia todo dia', 'Didático');
    geraDadosLivro(3, 'Educação Especial', 'Professor');
    geraDadosLivro(4, 'Português 9º Ano', 'Didático');
    geraDadosLivro(5, 'Branca de Neve e 7 anões', 'Literatura');
    print('Entrei aqui');

  }

  geraDadosLivro(int id, String nome, String tipo){
    livro = Livro(id: id,nome: nome,tipo: tipo);
    listaLivros.add(livro);
    listaFiltrada.add(livro);
    print('lista ${listaFiltrada.length}');
  }

  /*
  alteraDadosLivro(LivrosTeste livroAlterado, int index){
    listaLivros.update((value) {
      listaLivros[index].id = livroAlterado.id;
      listaLivros[index].nome = livroAlterado.nome;
      listaLivros[index].tipo = livroAlterado.tipo;
    });*/
    //listaLivros.add(livro);
    //listaObservavel.add(livro);
    /*listaObservavel.update((value) {
      listaObservavel[index].id = livroAlterado.id;
      listaObservavel[index].nome = livroAlterado.nome;
      listaObservavel[index].tipo = livroAlterado.tipo;
    });
    debugPrint('lista ${listaObservavel.length}');
  }*/

  //Livros get livrosCriados => this.livro;
  //RxList<Livros> get livrosLista => listaLivros;

  void filtraLista(String filtro){

    try {
      listaFiltrada.clear();
      listaFiltrada = listaLivros.where((pesquisa)=>pesquisa.nome.toLowerCase().contains(filtro)
      ).toList().obs;

    }catch (e){
      print(e.toString());
    }
  }
/*
  void limparDados(){
    controladorId.text = '';
    controladorNome.text = '';
    controladorTipo.text = '';
    livroClicado = null;
    indexLivroClicado = 0;
  }
*/

}